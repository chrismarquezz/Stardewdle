import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

// ESM-safe __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load and parse crops.json
const crops = JSON.parse(
  readFileSync(path.join(__dirname, "crops.json"), "utf8")
);

export const handler = async (event) => {
  let guess;
  try {
    guess = JSON.parse(event.body).guess.toLowerCase();
    if (!crops[guess]) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Invalid crop name." }),
      };
    }
  } catch {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Invalid request format." }),
    };
  }

  const answer = "potato";
  const guessed = crops[guess];
  const target = crops[answer];

  const compareNumber = (a, b) =>
    a === b ? "match" : a > b ? "higher" : "lower";

  const result = {
    type: guessed.type === target.type ? "match" : "mismatch",
    regrows: guessed.regrows === target.regrows ? "match" : "mismatch",
    season: JSON.stringify(guessed.season) === JSON.stringify(target.season)
      ? "match"
      : guessed.season.some(s => target.season.includes(s))
      ? "partial"
      : "mismatch",
    growth_time: compareNumber(guessed.growth_time, target.growth_time),
    xp_gain: compareNumber(guessed.xp_gain, target.xp_gain),
    energy: compareNumber(guessed.energy, target.energy),
    health: compareNumber(guessed.health, target.health),
    base_price: compareNumber(guessed.base_price, target.base_price),
    color: guessed.color === target.color ? "match" : "mismatch",
    recipe_usage_count: compareNumber(
      guessed.recipe_usage_count,
      target.recipe_usage_count
    ),
  };

  return {
    statusCode: 200,
    headers: { "Access-Control-Allow-Origin": "*" },
    body: JSON.stringify({ result }),
  };
};
